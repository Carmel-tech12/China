﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.Net;
using System.Xml;
using System.Diagnostics;
using System.Configuration;
using System.Data.SqlClient;
//
namespace DownloadFromUrl
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine e = new Engine();
        }
    }
    class Engine
    {
        public Engine()
        {
            LoadGlobalParameters();
            LoadDataForzip();
        }
        private HttpWebRequest request;
        private CookieContainer cookieContainer = new CookieContainer();

        private static string m_ConnectionString = string.Empty;
        public static string m_folderpath = string.Empty;
        //add by shira
        public static string m_folderpathforzip = string.Empty;
        public static string m_userforzip = string.Empty;
        public static string m_passforzip = string.Empty;

        public static string m_user = string.Empty;
        public static string m_pass = string.Empty;
        public static string m_url = string.Empty;
        //add by shira
        public static string m_urlzip = string.Empty;

        XmlDocument doc = new XmlDocument();

        private void LoadGlobalParameters()
        {
            try
            {
                doc.Load(@"" + ConfigurationManager.AppSettings["pathXml"]);
            }
            catch (Exception ex)
            {

              //  EventManager.WriteEventErrorMessage("can not load the doc", ex);
            }

            m_ConnectionString = doc.SelectSingleNode(@"Parameters/ConenctionString").InnerText + "&quot;";
            m_user = doc.SelectSingleNode(@"Parameters/Name").InnerText;
            m_pass = doc.SelectSingleNode(@"Parameters/Pass").InnerText;

            //add by shira
            m_userforzip = doc.SelectSingleNode(@"Parameters/Nameforzip").InnerText;
            m_passforzip = doc.SelectSingleNode(@"Parameters/Passforzip").InnerText;

            m_url = doc.SelectSingleNode(@"Parameters/Url").InnerText;
            //add by shira
            m_urlzip = doc.SelectSingleNode(@"Parameters/UrlZip").InnerText;


            //  m_nameView = doc.SelectSingleNode(@"Parameters/nameView").InnerText;
            m_folderpath = doc.SelectSingleNode(@"Parameters/folderpath").InnerText;
            //add by shira
            m_folderpathforzip = doc.SelectSingleNode(@"Parameters/folderpathforzip").InnerText;
                          
           // ConnectionManager.ConnectionString = m_ConnectionString;
           //  ConnectionManager.Provider = doc.SelectSingleNode(@"Parameters/Provider").InnerText;
           //   csv_file_path = ConfigurationManager.AppSettings["pathofcsvfile"].ToString();

        }
       
        public void LoadDataForzip1()
        {
            string command;
            XmlNodeList prodedursList = doc.GetElementsByTagName("zipUrl");  // XmlNodeList prodedursList = doc.GetElementsByTagName("Prodedurs");

            foreach (XmlNode pro in prodedursList)
            {
                //specificUrl contain the sequel of the url
                string specificUrl = pro.Attributes["myUrl"].Value;
             
                command = pro.InnerText;
                try
                {
                    try
                    {
       
                       doLogin(m_userforzip, m_passforzip, m_urlzip);

                        //if success do login
                        try
                        {
                            //EventManager.WriteEventInfoMessage("try upload file");
                         //  uploadfile(file, specificUrl);
                           // EventManager.WriteEventInfoMessage("finish upload file");
                        }
                        catch (Exception ex)
                        {
                          //  EventManager.WriteEventInfoMessage("cath upload file");
                        }
                        try
                        {
                          //  EventManager.WriteEventInfoMessage("try do logout");
                          doLogout(m_urlzip);
                        }
                        catch (Exception ex)
                        {
                          //  EventManager.WriteEventInfoMessage("cath do loout");
                        }


                    }
                    catch (Exception ex)
                    {
                       // EventManager.WriteEventErrorMessage("catch login", ex);
                    }
                   
                }
                catch (Exception ex)
                {
                 //   EventManager.WriteEventErrorMessage("Error while reading procedur from China", ex);

                }

             }
        }
        public void LoadDataForzip()
        {
            string command;
            XmlNodeList prodedursList = doc.GetElementsByTagName("zipUrl");  

            foreach (XmlNode pro in prodedursList)
            {
                //specificUrl contain the sequel of the url
                string specificUrl = pro.Attributes["myUrl"].Value;

                command = pro.InnerText;
                try
                {

                    doLogin(m_userforzip, m_passforzip, m_urlzip);

                    //  doLogout(m_urlzip);
                }
                catch
                {
                }
            }
        }
        private void uploadfile(string filePath, string specificUrl)
        {
            string url = m_url + specificUrl;//@"importcustomercards/exportcustomercards/importcsv";
            Console.WriteLine(url);
            //Identificate separator
            string boundary = "---------------------------" + DateTime.Now.Ticks.ToString("x");
            //Encoding
            byte[] boundarybytes = System.Text.Encoding.ASCII.GetBytes("\r\n--" + boundary + "\r\n");

            //Creation and specification of the request
            HttpWebRequest wr = (HttpWebRequest)WebRequest.Create(url); //sVal is id for the webService
            wr.CookieContainer = cookieContainer;
            wr.ContentType = "multipart/form-data; boundary=" + boundary;
            wr.Method = "POST";
            wr.KeepAlive = true;
            wr.Credentials = System.Net.CredentialCache.DefaultCredentials;

            //string sAuthorization = "login:password";//AUTHENTIFICATION BEGIN
            //byte[] toEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(sAuthorization);
            //string returnValue = System.Convert.ToBase64String(toEncodeAsBytes);
            //wr.Headers.Add("Authorization: Basic " + returnValue); //AUTHENTIFICATION END
            Stream rs = wr.GetRequestStream();


            string formdataTemplate = "Content-Disposition: form-data; name=\"{0}\"\r\n\r\n{1}"; //For the POST's format

            //Writting of the file
            rs.Write(boundarybytes, 0, boundarybytes.Length);
            byte[] formitembytes = System.Text.Encoding.UTF8.GetBytes(filePath);
            rs.Write(formitembytes, 0, formitembytes.Length);

            rs.Write(boundarybytes, 0, boundarybytes.Length);

            string headerTemplate = "Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n";
            string header = string.Format(headerTemplate, "file", "AAAAAAA.csv", wr.ContentType);
            byte[] headerbytes = System.Text.Encoding.UTF8.GetBytes(header);
            rs.Write(headerbytes, 0, headerbytes.Length);

            FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            byte[] buffer = new byte[4096];
            int bytesRead = 0;
            while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) != 0)
            {
                rs.Write(buffer, 0, bytesRead);
            }
            fileStream.Close();

            byte[] trailer = System.Text.Encoding.ASCII.GetBytes("\r\n--" + boundary + "--\r\n");
            rs.Write(trailer, 0, trailer.Length);
            rs.Close();
            rs = null;

            WebResponse wresp = null;
            try
            {
                //Get the response
                wresp = wr.GetResponse();
                Stream stream2 = wresp.GetResponseStream();
                StreamReader reader2 = new StreamReader(stream2);
                string responseData = reader2.ReadToEnd();
             //   EventManager.WriteEventInfoMessage("response is:\n" + responseData);

            }
            catch (Exception ex)
            {
                string s = ex.Message;
            }
            finally
            {
                if (wresp != null)
                {
                    wresp.Close();
                    wresp = null;
                }
                wr = null;
            }



        }

        public bool doLogin(string uid, string pwd, string url)
        {
            // Create a request using a URL that can receive a post. 
            request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.CookieContainer = cookieContainer;
            //added by liat in case customer has proxy 25/04/2016  
            IWebProxy wp = WebRequest.DefaultWebProxy;
            wp.Credentials = CredentialCache.DefaultCredentials;
            request.Proxy = wp;
            //end Change
            // Set the Method property of the request to POST.
            request.Method = "POST";

            // Set the ContentType property of the WebRequest.
            request.ContentType = "application/x-www-form-urlencoded";

            // Create POST data and convert it to a byte array.
            string postData = "email=" + uid + "&password=" + pwd;
            byte[] byteArray = Encoding.UTF8.GetBytes(postData);

            // Set the ContentLength property of the WebRequest.
            request.ContentLength = byteArray.Length;
            request.KeepAlive = true;

            // Get the request stream.
            using (Stream dataStream = request.GetRequestStream())
            {
                dataStream.Write(byteArray, 0, byteArray.Length);
            }
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                response.Cookies = request.CookieContainer.GetCookies(request.RequestUri);
                response.Close();
            }
            catch (WebException we)
            {
            }
            catch (Exception we)
            {
            }
            //HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            //response.Cookies = request.CookieContainer.GetCookies(request.RequestUri);
            //response.Close();
            return true;

        }
      
       
        public static bool DownloadFile(string filenameXML)
        {
            string NewSourceFilePath = @"C:\shira\ForChina\FolderOfZip\45451.zip";
              HttpWebRequest request;
              HttpWebResponse response = null;
              FileStream fs = null;
              long startpoint = 0;
           //   NewSourceFilePath=filenameXML;

              fs = File.Create(NewSourceFilePath);
              request = (HttpWebRequest)WebRequest.Create("https://chaina-motorsltd.dira2.co.il/systems/downloadAllZipFiles");
               request.KeepAlive = false;
           request.ProtocolVersion = HttpVersion.Version11;
               request.Method = "GET";
          request.ContentType = "gzip";
            request.Timeout=10000;
          request.Headers.Add("xRange", "bytes " + startpoint + "-");
         response = (HttpWebResponse)request.GetResponse();
        Stream streamResponse = response.GetResponseStream();
        byte[] buffer = new byte[1024];
        int read;
        while ((read = streamResponse.Read(buffer, 0, buffer.Length)) > 0){
         fs.Write(buffer, 0, read);}
        fs.Flush();fs.Close();
        return true;
        }
        //check
        public void try1()
        {
           /* ZipFile.CreateFromDirectory("source", "destination.zip",
                CompressionLevel.Optimal, false);

            // Extract the directory we just created.
            // ... Store the results in a new folder called "destination".
            // ... The new folder must not exist.
            ZipFile.ExtractToDirectory("destination.zip", "destination");*/
        }
        public void doLogout(string url)
        {
            // Create a request using a URL that can receive a post. 
            request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.CookieContainer = cookieContainer;

            // Set the Method property of the request to POST.
            request.Method = "GET";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            response.Close();
        }
    }
}
