﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.Net;
using System.Xml;
using System.Diagnostics;
using System.Configuration;

using System.Text.RegularExpressions;
using Microsoft.VisualBasic.FileIO;
using System.Data.SqlClient;

namespace DownLoadUpLoadDataService
{
    class Engine
    {
        private HttpWebRequest request;
        private CookieContainer cookieContainer = new CookieContainer();

        private static string m_ConnectionString = string.Empty;
        public static string m_folderpath = string.Empty;        
        public static string m_user = string.Empty;
        public static string m_pass = string.Empty;
        public static string m_url = string.Empty;
       // by shira
     //   public static string m_nameView = string.Empty;
        XmlDocument doc = new XmlDocument();
      
        public Engine()
        {
            LoadGlobalParameters();
        }

        private void LoadGlobalParameters()
        {
            try
            {
               // doc.Load("Config.xml");
               // doc.Load(@"C:\Program Files\UpLoadDataService\UpLoadDataService\bin\Debug\Config.xml");
                
                doc.Load(@""+ConfigurationManager.AppSettings["pathXml"]);
            }
            catch (Exception ex)
            {
                
               EventManager.WriteEventErrorMessage("can not load the doc", ex);
            }
            
            m_ConnectionString = doc.SelectSingleNode(@"Parameters/ConenctionString").InnerText+"&quot;";
            m_user = doc.SelectSingleNode(@"Parameters/Name").InnerText;
            m_pass = doc.SelectSingleNode(@"Parameters/Pass").InnerText;
            m_url = doc.SelectSingleNode(@"Parameters/Url").InnerText;
           
          //  m_nameView = doc.SelectSingleNode(@"Parameters/nameView").InnerText;
           
            m_folderpath = doc.SelectSingleNode(@"Parameters/folderpath").InnerText;
            ConnectionManager.ConnectionString = m_ConnectionString;
            ConnectionManager.Provider = doc.SelectSingleNode(@"Parameters/Provider").InnerText;

        }


       
       

        #region  Procedures
        public void LoadDataOfProcedurs()
        {

           /* string command;
            XmlNodeList prodedursList = doc.GetElementsByTagName("procedure");  // XmlNodeList prodedursList = doc.GetElementsByTagName("Prodedurs");

            foreach (XmlNode pro in prodedursList)
            {
                //specificUrl contain the sequel of the url
                string specificUrl = pro.Attributes["myUrl"].Value;
             
                command = pro.InnerText;
                try
                {
                    
                    DataSet dataSet = new DataSet();
                    dataSet = ConnectionManager.GetDataForProcedures(command);
                 //   string file = Savefile(ToCSV2(dataSet.Tables[0], ",", true), "from_Prodedure_"+command);
                   //string file = Savefile(ToCSV2(dataSet.Tables[0], ",", true), "from_Prodedure_" + DateTime.Now.ToFileTime() + ".csv");
                   //my test//string file = @"C:\rooti\temp\hash\Procedur_131474298261702609.csv";
                    try
                    {
                       EventManager.WriteEventInfoMessage("try do login");
                        doLogin(m_user, m_pass, m_url);

                        //if success do login
                        try
                        {
                            EventManager.WriteEventInfoMessage("try upload file");
                            uploadfile(file, specificUrl);
                            EventManager.WriteEventInfoMessage("finish upload file");
                        }
                        catch (Exception ex)
                        {
                            EventManager.WriteEventInfoMessage("cath upload file");
                        }
                        try
                        {
                            EventManager.WriteEventInfoMessage("try do logout");
                            doLogout(m_url);
                        }
                        catch (Exception ex)
                        {
                            EventManager.WriteEventInfoMessage("cath do loout");
                        }


                    }
                    catch (Exception ex)
                    {
                        EventManager.WriteEventErrorMessage("catch login", ex);
                    }
                    
                    
                    
                   


                }
                catch (Exception ex)
                {
                    EventManager.WriteEventErrorMessage("Error while reading procedur from China", ex);

                }

             }*/
        }


        #endregion



        #region  Queries
       /* public void LoadDataOfQueries()
        {
            string command;
          XmlNodeList QueriesList = doc.GetElementsByTagName("Query");  // XmlNodeList prodedursList = doc.GetElementsByTagName("Prodedurs");
            EventManager.WriteEventInfoMessage("QueriesList");
            foreach (XmlNode pro in QueriesList)
            {

                command = pro.InnerText;
                //specificUrl contain the sequel of the url
                string specificUrl = pro.Attributes["myUrl"].Value;
                string nameView = pro.Attributes["myUrl"].Value;
                EventManager.WriteEventInfoMessage("nameView");
               
               
                int x = nameView.IndexOf("/",2);
                EventManager.WriteEventInfoMessage("x" + " " + x.ToString());
                nameView = nameView.Replace("/", " ");
                EventManager.WriteEventInfoMessage("nameView" + " " + nameView);
                nameView=nameView.Substring(0,x);
                EventManager.WriteEventInfoMessage("nameView" + " " + nameView);
             
                try
                {
                   
                    DataSet dataSet = new DataSet();
                    dataSet = ConnectionManager.GetDataForQueries(command);
                    //string file = Savefile(ToCSV2(dataSet.Tables[0], ",", true), );
                    //by shira
                  
                 //   string file = Savefile(ToCSV2(dataSet.Tables[0], ",", true), nameView);
                    try
                    {
                        EventManager.WriteEventInfoMessage("try do login");
                        doLogin(m_user, m_pass, m_url);

                        //if success do login
                        try
                        {
                            EventManager.WriteEventInfoMessage("try upload file");
                           // uploadfile(file, specificUrl);
                            EventManager.WriteEventInfoMessage("finish upload file");
                        }
                        catch (Exception ex)
                        {
                            EventManager.WriteEventInfoMessage("cath upload file");
                        }
                        try
                        {
                            EventManager.WriteEventInfoMessage("try do logout");
                            doLogout(m_url);
                        }
                        catch (Exception ex)
                        {
                            EventManager.WriteEventInfoMessage("cath do loout");
                        }
                    }
                    catch (Exception ex)
                    {
                        EventManager.WriteEventErrorMessage("catch login", ex);
                    }                    


                }
                catch (Exception ex)
                {
                    EventManager.WriteEventErrorMessage("Error while reading Query from China", ex);

                }

            }
        }*/


        #endregion

 
        public void InsertIntoSp()
        {
            string csv_file_path = @"D:\ShiraNew\file from namrata.txt";
            int NumML = NumDataTableML(csv_file_path);
            int NumML2 = NumML;
            while (NumML>0)
            {
                DataTable tblML = ConvertToDataTableML(csv_file_path, 19, (NumML2 - NumML));
            //    DataTable tblCL = ConvertToDataTableCL(csv_file_path, 11);
                // DataTable tblfiles = ConvertToDataFiles(csv_file_path,6);
             //  DataTable tfiles = InsertToFiles(tblCL);
                AddIntoPsRequestDetails(tblML);
             //   AddIntoPsRequestLineDetails(tblCL);
              //  AddIntoPsFiles(tfiles);
                NumML--;
            }
            //AddIntoPsFiles(tblfiles);
        }
        public int NumDataTableML(string filePath)
        {
            int mone = 0;
             string[] lines = System.IO.File.ReadAllLines(filePath);
             foreach (string line in lines)
             {
                 if (line.Substring(0, 2) == "ML")
                 {
                     mone++;
                 }
                    
             }
             return mone;
        }
       public DataTable InsertToFiles(DataTable tblCL)
        {
            DataTable tblFiles = new DataTable();
            for (int col = 0; col < 6; col++)
                tblFiles.Columns.Add(new DataColumn("Column" + (col + 1).ToString()));
            int ReqNo;
            string Descrptn, FileLink, FileName;
            DateTime AddDate, AddTime;
       foreach (DataRow dr in tblCL.Rows) 
       {
           ReqNo = int.Parse(dr[0].ToString());
           Descrptn = dr[11].ToString();
           FileLink = dr[2].ToString();
           FileName = (dr[12].ToString().Substring(0,dr[12].ToString().IndexOf(".")));
           AddDate = DateTime.Parse(dr[10].ToString());
           AddTime = DateTime.Parse(dr[10].ToString());
           DataRow workRow = tblFiles.NewRow();
           workRow[0] = ReqNo;
           workRow[1] = Descrptn;
           workRow[2] = FileLink;
           workRow[3] = FileName;
           workRow[4] = AddDate;
           workRow[5] = AddTime;
           tblFiles.Rows.Add(workRow);
        }
            return tblFiles;
        }
      /*  public bool Bdika(string filePath,string line)
        {
            string[] lines = System.IO.File.ReadAllLines(filePath);
            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i] == line)
                    return true;
            }
            return false;
        }*/
      
        public DataTable ConvertToDataFiles(string filePath, int numberOfColumns)
        {
            DataTable tblFiles = new DataTable();
            for (int col = 0; col < numberOfColumns; col++)
                tblFiles.Columns.Add(new DataColumn("Column" + (col + 1).ToString()));


            string[] lines = System.IO.File.ReadAllLines(filePath);
            string[] cols; DataRow dr;
            foreach (string line in lines)
            {
              //  if (Bdika(filePath, line) == false)
               // {
                    if (line.Substring(0, 2) == "ML")
                    {

                    }
                    else
                    {
                        if (line.Substring(0, 2) == "CL")
                        {

                        }
                        else
                        {
                            if (line.Substring(0, 2) == "FL")
                            {
                                cols = line.Substring(2).Replace("~%", "^").Split('^');
                                int i;
                                for (i = 0; i < (cols.Count() - 1); i++)
                                    cols[i] = cols[i + 1];
                                cols[i] = null;
                                dr = tblFiles.NewRow();
                                for (int cIndex = 0; cIndex < dr.ItemArray.Count(); cIndex++)
                                {
                                    dr[cIndex] = cols[cIndex];
                                }
                                tblFiles.Rows.Add(dr);
                            }
                        }

                    }
                //}
            }

            return tblFiles;
        }
      //  https://stackoverflow.com/questions/20860101/how-to-read-text-file-to-datatable
        public DataTable ConvertToDataTableCL(string filePath, int numberOfColumns,int NumML)
        {
            DataTable tblCL = new DataTable();
           for (int col = 0; col <( numberOfColumns + 2); col++)
              tblCL.Columns.Add(new DataColumn("Column" + (col + 1).ToString()));

            string[] lines = System.IO.File.ReadAllLines(filePath);
            string[] cols; DataRow dr;
            int mone = 0;
            int d=0;
            foreach (string line in lines)
            {
               // if (Bdika(filePath, line) == false)
              //  {
                if (line.Substring(0, 2) == "ML")
                {
                    mone++;
                    if (mone == NumML)
                    {
                        d = 1;
                    }
                }
                   // else
                   // {
               // if (line.Count() % 3 == 0)
              //  {
               // }
                    if (line.Substring(0, 2) == "CL" && d==1)
                    {
                        // var cols = line.Substring(2).Replace("~%", ":").Split(':');
                        cols = line.Substring(2).Replace("~%", "^").Split('^');
                        int i;
                        for (i = 0; i < (cols.Count() - 1); i++)
                            cols[i] = cols[i + 1];
                        cols[i] = null;
                        //cols = line.Substring(2).Replace("~%", "^").Replace("", "^").Split('^');
                        //  cols = cols.Split(':');

                        dr = tblCL.NewRow();
                        for (int cIndex = 0; cIndex < dr.ItemArray.Count(); cIndex++)
                        {
                            dr[cIndex] = cols[cIndex];
                        }
                        tblCL.Rows.Add(dr);
                    }
                

                 //   }
              //  }
              
            }

            return tblCL;
        }
        public DataTable ConvertToDataTableML(string filePath, int numberOfColumns,int NumML)
        {
            int mone = 0;
            bool degel = false;
            DataTable tblML = new DataTable();
               for (int col = 0; col < numberOfColumns; col++)
                tblML.Columns.Add(new DataColumn("Column" + (col + 1).ToString()));


            string[] lines = System.IO.File.ReadAllLines(filePath);
            string[] cols; DataRow dr;
            foreach (string line in lines)
            {
               
               // if (Bdika(filePath, line) == false)
             //   {
                    if (line.Substring(0, 2) == "ML")
                    {
                        mone++;
                        if (mone == NumML)
                        {
                            degel = true;
                            // var cols = line.Substring(2).Replace("~%", ":").Split(':');
                            cols = line.Substring(2).Replace("~%", "^").Split('^');
                            int i;
                            for (i = 0; i < (cols.Count() - 1); i++)
                                cols[i] = cols[i + 1];
                            cols[i] = null;
                            //  cols = cols.Split(':');

                            dr = tblML.NewRow();
                            for (int cIndex = 0; cIndex < dr.ItemArray.Count(); cIndex++)
                            {
                                dr[cIndex] = cols[cIndex];
                            }
                            tblML.Rows.Add(dr);
                        }
                    }
                    else
                    {
                        if (line.Substring(0, 2) == "CL" && degel)
                        {
                           DataTable tblCL = ConvertToDataTableCL(filePath, 11,NumML);
                           AddIntoPsRequestLineDetails(tblCL);
                           DataTable tfiles = InsertToFiles(tblCL);
                           AddIntoPsFiles(tfiles);
                           break;
                        }

                    }
                //}

            }

            return tblML;
        }
        public bool BdikaIfExsist(int ReqNo)
        {
            using (SqlConnection con = new SqlConnection(m_ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("IsExistRequestDetails", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@ReqNo", SqlDbType.Int).Value = ReqNo;
                    con.Open();
            //    cmd.ExecuteNonQuery();
               // int retunvalue = (int.Parse)(cmd.Parameters["@ReqNo"].Value.ToString());
                    SqlDataReader rdr = cmd.ExecuteReader();
                    
                    con.Close();
                }
            }  
             
   
            return true;
        }
         //  https://social.msdn.microsoft.com/Forums/vstudio/en-US/f14523f8-3a40-451b-983b-ae4f5fd12697/how-to-load-data-from-csv-file-in-temp-table-in-c?forum=csharpgeneral
            public void AddIntoPsRequestDetails(DataTable dt)
        {
       // https://stackoverflow.com/questions/29046715/extract-values-from-datatable-with-single-row

            int i = 0, count = dt.Rows.Count; ;
            //פרמטרים של טבלת CA_RequestDetails
            string CampaignCd, EstCost1, JCNum1, RequestChangeFlag1, TimeStamp1;
            int ReqNo ,KM ,RequestTypeCd ,EstCost,JCNum,RequestChangeFlag;
	        string ApproverName ,LicNum ,RequestTypeNm ,RequestDesc ,CampaignNm ,EntryHr,ExitHr ,Garage;
	        DateTime RequestDt, EntryDt ,ExitDt ,TimeStamp;
            if (dt.Rows.Count > 0 && count > 0)
            {
                count--;
              DataRow row = dt.Rows[0];
                //זימון פונקציה שתבדוק עבור סוג בקשה אם קיים אם כן תעדכן תאור אחרת תוסיף לטבלה
         //    bool fleg= BdikaIfExsist(int.Parse(row[0].ToString()));
               ReqNo = int.Parse(row[0].ToString());         
	           ApproverName = row[1].ToString(); 
	           LicNum = row[2].ToString(); 
	           KM = int.Parse(row[3].ToString()); 
              RequestDt = DateTime.Parse( row[4].ToString()); 
	          RequestTypeCd= int.Parse(row[5].ToString()); 
	          RequestTypeNm = row[6].ToString(); 
	          RequestDesc = row[7].ToString(); 
             CampaignCd = row[8].ToString();
	          CampaignNm = row[9].ToString(); 
	          EntryDt = DateTime.Parse(row[10].ToString()); 
	          EntryHr = row[11].ToString(); 
	          ExitDt = DateTime.Parse(row[12].ToString()); 
	          ExitHr = row[13].ToString(); 
	          Garage = row[14].ToString(); 
	        //  EstCost = int.Parse(row[15].ToString());
              EstCost = int.Parse(row[15].ToString());
	          JCNum = int.Parse(row[16].ToString());
            //  JCNum = row[16].ToString();
	          RequestChangeFlag = int.Parse(row[17].ToString()); 
	          TimeStamp = DateTime.Parse(row[18].ToString());
             // RequestChangeFlag = row[17].ToString();
             // TimeStamp = row[18].ToString(); 
               
            using (SqlConnection con = new SqlConnection(m_ConnectionString)) {
                using (SqlCommand cmd = new SqlCommand("RequestDetails", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@ReqNo", SqlDbType.Int).Value = ReqNo;
                    cmd.Parameters.Add("@ApproverName", SqlDbType.NVarChar).Value = ApproverName;
                    cmd.Parameters.Add("@LicNum", SqlDbType.NVarChar).Value = LicNum;
                    cmd.Parameters.Add("@KM", SqlDbType.Int).Value = KM;
                    cmd.Parameters.Add("@RequestDt", SqlDbType.DateTime).Value = RequestDt;
                    cmd.Parameters.Add("@RequestTypeCd", SqlDbType.Int).Value = RequestTypeCd;
                    cmd.Parameters.Add("@RequestTypeNm", SqlDbType.NVarChar).Value = RequestTypeNm;
                    cmd.Parameters.Add("@RequestDesc", SqlDbType.NVarChar).Value = RequestDesc;
                    cmd.Parameters.Add("@CampaignCd", SqlDbType.NVarChar).Value = CampaignCd;
                    cmd.Parameters.Add("@CampaignNm", SqlDbType.NVarChar).Value = CampaignNm;
                    cmd.Parameters.Add("@EntryDt", SqlDbType.DateTime).Value = EntryDt;
                    cmd.Parameters.Add("@EntryHr", SqlDbType.NVarChar).Value = EntryHr;
                    cmd.Parameters.Add("@ExitDt", SqlDbType.DateTime).Value = ExitDt;
                    cmd.Parameters.Add("@ExitHr", SqlDbType.NVarChar).Value = ExitHr;
                    cmd.Parameters.Add("@Garage", SqlDbType.NVarChar).Value = Garage;
                 
                    cmd.Parameters.Add("@EstCost", SqlDbType.Int).Value = EstCost;
                    cmd.Parameters.Add("@JCNum", SqlDbType.Int).Value = JCNum;
                    cmd.Parameters.Add("@RequestChangeFlag", SqlDbType.Int).Value = RequestChangeFlag;
                    cmd.Parameters.Add("@TimeStamp", SqlDbType.DateTime).Value = TimeStamp;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                } 
             }  
             
   
        }
      }
        public void AddIntoPsRequestLineDetails(DataTable dt)
        {
            int i =0,count=dt.Rows.Count;
            //פרמטרים של טבלת CA_RequestLineDetails
            char Qntty;
            int ReqNo, RowReqNo,BiilTo,JCNum,StatusFlag;
            string ItemCode,RequestStts,RejectRsn,RjctMsg;
            DateTime Timestamp;
            while (dt.Rows.Count > 0 && i < 3 && count > 0)
            {
                count--;
                DataRow row = dt.Rows[i++];
                ReqNo = int.Parse(row[0].ToString());
                RowReqNo = int.Parse(row[1].ToString());
                ItemCode = row[2].ToString();
                Qntty = Char.Parse(row[3].ToString());
                RequestStts = row[4].ToString();
                RejectRsn = row[5].ToString();
                BiilTo = int.Parse(row[6].ToString());
                JCNum = int.Parse(row[7].ToString());
                RjctMsg = row[8].ToString();
                StatusFlag = int.Parse(row[9].ToString());
                Timestamp = DateTime.Parse(row[10].ToString());
                using (SqlConnection con = new SqlConnection(m_ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("RequestLineDetails", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@ReqNo", SqlDbType.Int).Value = ReqNo;
                        cmd.Parameters.Add("@RowReqNo", SqlDbType.Int).Value = RowReqNo;
                        cmd.Parameters.Add("@ItemCode", SqlDbType.NVarChar).Value = ItemCode;
                        cmd.Parameters.Add("@Qntty", SqlDbType.Char).Value = Qntty;
                        cmd.Parameters.Add("@RequestStts", SqlDbType.NVarChar).Value = RequestStts;
                        cmd.Parameters.Add("@RejectRsn", SqlDbType.NVarChar).Value = RejectRsn;
                        cmd.Parameters.Add("@BiilTo", SqlDbType.Int).Value = BiilTo;
                        cmd.Parameters.Add("@JCNum", SqlDbType.Int).Value = JCNum;
                        cmd.Parameters.Add("@RjctMsg", SqlDbType.NVarChar).Value = RjctMsg;
                        cmd.Parameters.Add("@StatusFlag", SqlDbType.Int).Value = StatusFlag;
                        cmd.Parameters.Add("@Timestamp", SqlDbType.DateTime).Value = Timestamp;
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }


            }
        }
        public void AddIntoPsFiles(DataTable dt)
        {
            int i = 0, count = dt.Rows.Count;
            //פרמטרים של טבלת CA_Files
            int ReqNo;
            string Descrptn,FileLink,FileName;
            DateTime AddDate,AddTime;
            while (dt.Rows.Count > 0 && count > 0)
            {
                count--;
                DataRow row = dt.Rows[i++];
                ReqNo = int.Parse(row[0].ToString());
                Descrptn = row[1].ToString();
                FileLink = row[2].ToString();
                FileName =row[3].ToString();
                AddDate = DateTime.Parse(row[4].ToString());
                AddTime = DateTime.Parse(row[5].ToString());
                using (SqlConnection con = new SqlConnection(m_ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Files", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@ReqNo", SqlDbType.Int).Value = ReqNo;
                        cmd.Parameters.Add("@Descrptn", SqlDbType.NVarChar).Value = Descrptn;
                        cmd.Parameters.Add("@FileLink", SqlDbType.NVarChar).Value = FileLink;
                        cmd.Parameters.Add("@FileName", SqlDbType.NVarChar).Value = FileName;
                        cmd.Parameters.Add("@AddDate", SqlDbType.DateTime).Value = AddDate;
                        cmd.Parameters.Add("@AddTime", SqlDbType.DateTime).Value = AddTime;
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }


            }
        }
    }
}

