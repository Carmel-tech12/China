﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.Net;
using System.Xml;
using System.Diagnostics;
using System.Configuration;

using System.Text.RegularExpressions;
using Microsoft.VisualBasic.FileIO;
using System.Data.SqlClient;

namespace DownLoadUpLoadDataService
{
    class Engine
    {
        //private HttpWebRequest request;
        private CookieContainer cookieContainer = new CookieContainer();

        private static string m_ConnectionString = string.Empty;
        public static string m_folderpath = string.Empty;        
        public static string m_user = string.Empty;
        public static string m_pass = string.Empty;
        public static string m_url = string.Empty;
        public static string csv_file_path = string.Empty; 
        XmlDocument doc = new XmlDocument();
      
        public Engine()
        {
            LoadGlobalParameters();
        }

        private void LoadGlobalParameters()
        {
            try
            {
               // doc.Load("Config.xml");
               // doc.Load(@"C:\Program Files\UpLoadDataService\UpLoadDataService\bin\Debug\Config.xml");
                
                doc.Load(@""+ConfigurationManager.AppSettings["pathXml"]);
            }
            catch (Exception ex)
            {
                
               EventManager.WriteEventErrorMessage("can not load the doc", ex);
            }
            
            m_ConnectionString = doc.SelectSingleNode(@"Parameters/ConenctionString").InnerText+"&quot;";
            m_user = doc.SelectSingleNode(@"Parameters/Name").InnerText;
            m_pass = doc.SelectSingleNode(@"Parameters/Pass").InnerText;
            m_url = doc.SelectSingleNode(@"Parameters/Url").InnerText;
          //  m_nameView = doc.SelectSingleNode(@"Parameters/nameView").InnerText;
            m_folderpath = doc.SelectSingleNode(@"Parameters/folderpath").InnerText;
            ConnectionManager.ConnectionString = m_ConnectionString;
            ConnectionManager.Provider = doc.SelectSingleNode(@"Parameters/Provider").InnerText;
            csv_file_path = ConfigurationManager.AppSettings["pathofcsvfile"].ToString();
        }
        public static bool degel = true;
        public void InsertIntoSp()
        {
            
               //string csv_file_path = @"D:\ShiraNew\file from namrata.txt";
                EventManager.WriteEventInfoMessage("start ConvertToDataTable ML from TxtFile");
               //shira DataTable tblML = ConvertToDataTableML(csv_file_path, 23);
                DataTable tblML = ConvertToDataTableML(csv_file_path, 25);
                EventManager.WriteEventInfoMessage("finish ConvertToDataTable ML from TxtFile");
               
                EventManager.WriteEventInfoMessage("start AddIntoPsRequestDetails ML from TxtFile");
                AddIntoPsRequestDetails(tblML);
                EventManager.WriteEventInfoMessage("finish AddIntoPsRequestDetails ML from TxtFile");
               
                EventManager.WriteEventInfoMessage("start ConvertToDataTable CL from TxtFile");
                //shira DataTable tblCL = ConvertToDataTableCL(csv_file_path, 13);
                DataTable tblCL = ConvertToDataTableCL(csv_file_path, 11);
                EventManager.WriteEventInfoMessage("finish ConvertToDataTable CL from TxtFile");
               
                EventManager.WriteEventInfoMessage("start AddIntoPsRequestDetails CL from TxtFile");
                CA_RequestLineDetailsPs(tblCL);
                EventManager.WriteEventInfoMessage("finish AddIntoPsRequestDetails CL from TxtFile");
               
                EventManager.WriteEventInfoMessage("start InsertToFiles from TxtFile");
                DataTable tfiles = InsertToFiles(tblCL);
              /* if(degel)
                  AddIntoPsFiles(tfiles);
               else
                   AddIntoPsFiles2(tfiles);*/
                EventManager.WriteEventInfoMessage("finish InsertToFiles from TxtFile");
        }
       public DataTable InsertToFiles(DataTable tblCL)
        {
            DataTable tblFiles = new DataTable();
            for (int col = 0; col < 11; col++)
                tblFiles.Columns.Add(new DataColumn("Column" + (col + 1).ToString()));
            int ReqNo, LineId;
            string Descrptn="", FileLink, FileName="",AddTime="";
            DateTime AddDate=new DateTime(); 
           degel = true;
       foreach (DataRow dr in tblCL.Rows) 
       {
          
           ReqNo = int.Parse(dr[0].ToString());
           LineId = int.Parse(dr[1].ToString());
         //  Descrptn = (dr[10].ToString().Substring(dr[12].ToString().IndexOf(".")));
           FileLink = "";
           if (dr[9].ToString() != "" && dr[10].ToString() != "")
           {
               degel = true;
               Descrptn = (dr[9].ToString().Substring(dr[9].ToString().IndexOf(".") + 1));
               FileName = (dr[9].ToString().Substring(0, dr[9].ToString().IndexOf(".")));
               AddDate = DateTime.Parse(dr[10].ToString().Substring(0, 11));
               AddTime = dr[10].ToString().Substring(11);
           }
           else
               degel = false;
           DataRow workRow = tblFiles.NewRow();
           workRow[0] = ReqNo;
           workRow[1] = LineId;
           workRow[2] = Descrptn;
           workRow[3] = FileLink;
           if (dr[9].ToString() != "" && dr[10].ToString() != "")
           {
               degel = true;
               workRow[4] = FileName;
               workRow[5] = AddDate;
               workRow[6] = AddTime;
           }
           else
               degel = false;
           
           tblFiles.Rows.Add(workRow);
      
           if(degel)
              AddIntoPsFiles(tblFiles);
           else
               AddIntoPsFiles2(tblFiles);
       }
            return tblFiles;
        }

      //  https://stackoverflow.com/questions/20860101/how-to-read-text-file-to-datatable
        public DataTable ConvertToDataTableCL(string filePath, int numberOfColumns)
        {
            DataTable tblCL = new DataTable();
            int countrow = 0;
            for (int col = 0; col < (numberOfColumns); col++)
                tblCL.Columns.Add(new DataColumn("Column" + (col + 1).ToString()));
            string[] lines = System.IO.File.ReadAllLines(filePath);
            string[] cols; DataRow dr;
            string s;
            foreach (string line in lines)
            {
                if (line.Substring(0, 2) == "ML")
                {
                }
                if (line.Substring(0, 2) == "CL")
                {
                    cols = line.Substring(2).Replace("~%", "^").Split('^');
                    int i;
                    for (i = 0; i < (cols.Count() - 1); i++)
                        cols[i] = cols[i + 1];
                    cols[i] = null;
                    dr = tblCL.NewRow();
                    countrow = dr.ItemArray.Count();
                    for (int cIndex = 0; cIndex < (countrow-2); cIndex++)
                    {
                        dr[cIndex] = cols[cIndex];
                    }
                  //  EventManager.WriteEventInfoMessage("");
                     s = cols[9];
                     if (s != null)
                    {
                        //  countrow = countrow - 2;
                        for (int cIndex = (countrow-2); cIndex < (countrow); cIndex++)
                        {
                            dr[cIndex] = cols[cIndex];
                        }
                    }
                    tblCL.Rows.Add(dr);
                }
            }

            return tblCL;
        }
        public DataTable ConvertToDataTableML(string filePath, int numberOfColumns)
        {
            DataTable tblML = new DataTable();
            for (int col = 0; col < numberOfColumns; col++)
                tblML.Columns.Add(new DataColumn("Column" + (col + 1).ToString()));


            string[] lines = System.IO.File.ReadAllLines(filePath);
            string[] cols; DataRow dr;
            foreach (string line in lines)
            {
                if (line.Substring(0, 2) == "ML")
                {
                        cols = line.Substring(2).Replace("~%", "^").Split('^');
                        int i;
                        for (i = 0; i < (cols.Count() - 1); i++)
                            cols[i] = cols[i + 1];
                        cols[i] = null;
                        dr = tblML.NewRow();
                        for (int cIndex = 0; cIndex < dr.ItemArray.Count(); cIndex++)
                        {
                            dr[cIndex] = cols[cIndex];
                        }
                        tblML.Rows.Add(dr);
                  }
            }
            return tblML;
        }
         //  https://social.msdn.microsoft.com/Forums/vstudio/en-US/f14523f8-3a40-451b-983b-ae4f5fd12697/how-to-load-data-from-csv-file-in-temp-table-in-c?forum=csharpgeneral
            public void AddIntoPsRequestDetails(DataTable dt)
        {
       // https://stackoverflow.com/questions/29046715/extract-values-from-datatable-with-single-row

            int i = 0, count = dt.Rows.Count; 
            //פרמטרים של טבלת CA_RequestDetails
            string CampaignCd, EstCost;
            int ReqNo, KM, RequestTypeCd, JCNum, RequestChangeFlag, RequestRsnCd, RequestCd, StatusFlag;//EstCost
            string ApproverName, LicNum, RequestTypeNm, RequestDesc, CampaignNm, EntryHr, ExitHr, Garage, RequestStts, RequestRsnNm, Notes;
            DateTime RequestDt, EntryDt, ExitDt, TimeStamp, OpenDt, FirstRspnsDt;
             while (dt.Rows.Count > 0 && count > 0)
              {
                count--;
              DataRow row = dt.Rows[i++];
                //זימון פונקציה שתבדוק עבור סוג בקשה אם קיים אם כן תעדכן תאור אחרת תוסיף לטבלה
              ReqNo = int.Parse(row[0].ToString());
              RequestStts = row[1].ToString();
	          ApproverName = row[2].ToString(); 
	          LicNum = row[3].ToString(); 
	          KM = int.Parse(row[4].ToString()); 
              RequestDt = DateTime.Parse( row[5].ToString()); 
	          RequestTypeCd= int.Parse(row[6].ToString()); 
	          RequestTypeNm = row[7].ToString();
              RequestRsnCd = int.Parse(row[8].ToString());
              RequestRsnNm=row[9].ToString();
              RequestCd=int.Parse(row[10].ToString());
              RequestDesc = row[11].ToString(); 
              Notes=row[12].ToString();
              CampaignCd = row[13].ToString();
	          CampaignNm = row[14].ToString();
              OpenDt=DateTime.Parse(row[15].ToString());
              FirstRspnsDt = DateTime.Parse(row[16].ToString());
	          EntryDt = DateTime.Parse(row[17].ToString()); 
	          EntryHr = row[18].ToString(); 
	          ExitDt = DateTime.Parse(row[19].ToString()); 
	          ExitHr = row[20].ToString(); 
	          Garage = row[21].ToString(); 
              EstCost = row[22].ToString();
	         // JCNum = int.Parse(row[16].ToString());
	         // RequestChangeFlag = int.Parse(row[17].ToString()); 
	        // TimeStamp = DateTime.Parse(row[18].ToString());
              StatusFlag = int.Parse(row[23].ToString()); 
               TimeStamp = DateTime.Parse(row[24].ToString());
              EventManager.WriteEventInfoMessage("start ConnectionString to db for CA_RequestDetails table");
            using (SqlConnection con = new SqlConnection(m_ConnectionString)) {
                using (SqlCommand cmd = new SqlCommand("RequestDetails_temp", con))
                {
                    try
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@ReqNo", SqlDbType.Int).Value = ReqNo;
                        cmd.Parameters.Add("@RequestStts", SqlDbType.NVarChar).Value = RequestStts;
                        cmd.Parameters.Add("@ApproverName", SqlDbType.NVarChar).Value = ApproverName;
                        cmd.Parameters.Add("@LicNum", SqlDbType.NVarChar).Value = LicNum;
                        cmd.Parameters.Add("@KM", SqlDbType.Int).Value = KM;
                        cmd.Parameters.Add("@RequestDt", SqlDbType.DateTime).Value = RequestDt;
                        cmd.Parameters.Add("@RequestTypeCd", SqlDbType.Int).Value = RequestTypeCd;
                        cmd.Parameters.Add("@RequestTypeNm", SqlDbType.NVarChar).Value = RequestTypeNm;
                        cmd.Parameters.Add("@RequestRsnCd", SqlDbType.Int).Value = RequestRsnCd;
                        cmd.Parameters.Add("@RequestRsnNm", SqlDbType.NVarChar).Value = RequestRsnNm;
                        cmd.Parameters.Add("@RequestCd", SqlDbType.Int).Value = RequestCd;
                        cmd.Parameters.Add("@RequestDesc", SqlDbType.NVarChar).Value = RequestDesc;
                        cmd.Parameters.Add("@Notes", SqlDbType.NVarChar).Value = Notes;
                        cmd.Parameters.Add("@CampaignCd", SqlDbType.NVarChar).Value = CampaignCd;
                        cmd.Parameters.Add("@CampaignNm", SqlDbType.NVarChar).Value = CampaignNm;
                        cmd.Parameters.Add("@OpenDt", SqlDbType.DateTime).Value = OpenDt;
                        cmd.Parameters.Add("@FirstRspnsDt", SqlDbType.DateTime).Value = FirstRspnsDt;
                        cmd.Parameters.Add("@EntryDt", SqlDbType.DateTime).Value = EntryDt;
                        cmd.Parameters.Add("@EntryHr", SqlDbType.NVarChar).Value = EntryHr;
                        cmd.Parameters.Add("@ExitDt", SqlDbType.DateTime).Value = ExitDt;
                        cmd.Parameters.Add("@ExitHr", SqlDbType.NVarChar).Value = ExitHr;
                        cmd.Parameters.Add("@Garage", SqlDbType.NVarChar).Value = Garage;
                        cmd.Parameters.Add("@EstCost", SqlDbType.NVarChar).Value = EstCost;
                        //cmd.Parameters.Add("@JCNum", SqlDbType.Int).Value = JCNum;
                        //cmd.Parameters.Add("@RequestChangeFlag", SqlDbType.Int).Value = RequestChangeFlag;
                    //    cmd.Parameters.Add("@StatusFlag", SqlDbType.Int).Value = RequestChangeFlag;
                       // '@StatusFlag'
                      //  cmd.Parameters.Add("@TimeStamp", SqlDbType.DateTime).Value = TimeStamp;
                        cmd.Parameters.Add("@StatusFlag", SqlDbType.Int).Value = StatusFlag;
                        cmd.Parameters.Add("@TimeStamp", SqlDbType.DateTime).Value = TimeStamp;
                    }
                    catch (Exception e)
                    {
                        EventManager.WriteEventErrorMessage("failed to put values for CA_RequestDetails table",e);
                    }
                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception e)
                    {
                        EventManager.WriteEventErrorMessage("failed to open ConnectionString for CA_RequestDetails table", e);
                    }
                    try
                    {
                        con.Close();
                    }
                    catch (Exception e)
                    {
                        EventManager.WriteEventErrorMessage("failed to close ConnectionString for CA_RequestDetails table", e);
                    }
                } 
             }  
             
   
        }
      }
        public static void AddIntoPsRequestLineDetails(DataTable dt,int NumOfRow)
        {
            int i , count = dt.Rows.Count;
            //פרמטרים של טבלת CA_RequestLineDetails
            char Qntty;
            int ReqNo, LineId,BiilTo,JCNum,StatusFlag,Docentry,SBOLineId;
            string ItemCode,RequestStts,RejectRsn,RjctMsg,FileName;
            DateTime Timestamp,AddTime;
            i = count - NumOfRow;
            count = NumOfRow;
            while (dt.Rows.Count > 0 && count > 0)
            {
                count--;
                DataRow row = dt.Rows[i++];
                ReqNo = int.Parse(row[0].ToString());
                LineId = int.Parse(row[1].ToString());
                ItemCode = row[2].ToString();
                Qntty = Char.Parse(row[3].ToString());
                RequestStts = row[4].ToString();
                RejectRsn = row[5].ToString();
                BiilTo = int.Parse(row[6].ToString());
              /*  JCNum = int.Parse(row[7].ToString());
                RjctMsg = row[8].ToString();
                StatusFlag = int.Parse(row[9].ToString());
                Timestamp = DateTime.Parse(row[10].ToString());*/
                    Docentry=int.Parse(row[7].ToString());
                    SBOLineId=int.Parse(row[8].ToString());
                using (SqlConnection con = new SqlConnection(m_ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("RequestLineDetails_temp", con))
                    {
                        try
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@ReqNo", SqlDbType.Int).Value = ReqNo;
                            cmd.Parameters.Add("@LineId", SqlDbType.Int).Value = LineId;
                            cmd.Parameters.Add("@ItemCode", SqlDbType.NVarChar).Value = ItemCode;
                            cmd.Parameters.Add("@Qntty", SqlDbType.Char).Value = Qntty;
                            cmd.Parameters.Add("@RequestStts", SqlDbType.NVarChar).Value = RequestStts;
                            cmd.Parameters.Add("@RejectRsn", SqlDbType.NVarChar).Value = RejectRsn;
                            cmd.Parameters.Add("@BiilTo", SqlDbType.Int).Value = BiilTo;
                         /* cmd.Parameters.Add("@JCNum", SqlDbType.Int).Value = JCNum;
                            cmd.Parameters.Add("@RjctMsg", SqlDbType.NVarChar).Value = RjctMsg;
                            cmd.Parameters.Add("@StatusFlag", SqlDbType.Int).Value = StatusFlag;
                            cmd.Parameters.Add("@Timestamp", SqlDbType.DateTime).Value = Timestamp;*/
                            cmd.Parameters.Add("@Docentry", SqlDbType.Int).Value = Docentry;
                            cmd.Parameters.Add("@SBOLineId", SqlDbType.Int).Value = SBOLineId;
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to put values for CA_RequestLineDetails table", e);
                        }
                        try
                        {
                            con.Open();
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to open ConnectionString for CA_RequestLineDetails table", e);
                        }
                        try
                        {
                            con.Close();
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to close ConnectionString for CA_RequestLineDetails table", e);
                        }
                    }
                }


            }
        }
        public static void CA_RequestLineDetailsPs(DataTable dt)
        {
            int count = dt.Rows.Count,mone = 0; 
            string connectionString = m_ConnectionString;
       // https://stackoverflow.com/questions/9648934/insert-into-if-not-exists-sql-server
           /* string insertQuery = " IF NOT EXISTS (select * from CA_RequestLineDetails_temp where ReqNo = @ReqNo) \n\r" +
               " BEGIN \n\r" +
               "     INSERT into CA_RequestLineDetails_temp(ReqNo,LineId,ItemCode,Qntty,RequestStts,RejectRsn,BiilTo) VALUES(@ReqNo,@LineId,@ItemCode,@Qntty,@RequestStts,@RejectRsn,@BiilTo) \n\r" +
               " END \n\r " +
               " ELSE SELECT 0";*/
            string insertQuery = " IF NOT EXISTS (select * from CA_RequestLineDetails_temp where ReqNo = @ReqNo) \n\r" +
              " BEGIN \n\r" +
              "     INSERT into CA_RequestLineDetails_temp(ReqNo,LineId,ItemCode,Qntty,RequestStts,RejectRsn,BiilTo,Docentry,SBOLineId) VALUES(@ReqNo,@LineId,@ItemCode,@Qntty,@RequestStts,@RejectRsn,@BiilTo,@Docentry,@SBOLineId) \n\r" +
              " END \n\r " +
              " ELSE SELECT 0";
            using (SqlConnection connection = new SqlConnection(connectionString))
                while (count > 0 && count > 3)
                {
                    DataRow row = dt.Rows[mone];
                    CA_LogPs(dt, mone);
                   
                    count = count - 3;
                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        // define your parameters ONCE outside the loop, and use EXPLICIT typing
                        command.Parameters.Add("@ReqNo", SqlDbType.Int);
                        command.Parameters.Add("@LineId", SqlDbType.Int);
                        command.Parameters.Add("@ItemCode", SqlDbType.NVarChar);
                        command.Parameters.Add("@Qntty", SqlDbType.Char);
                        command.Parameters.Add("@RequestStts", SqlDbType.NVarChar);
                        command.Parameters.Add("@RejectRsn", SqlDbType.NVarChar);
                        command.Parameters.Add("@BiilTo", SqlDbType.Int);
                       /* command.Parameters.Add("@JCNum", SqlDbType.Int);
                        command.Parameters.Add("@RjctMsg", SqlDbType.NVarChar);
                        command.Parameters.Add("@StatusFlag", SqlDbType.Int);
                        command.Parameters.Add("@Timestamp", SqlDbType.DateTime);*/
                         command.Parameters.Add("@Docentry", SqlDbType.Int);
                         command.Parameters.Add("@SBOLineId", SqlDbType.Int);
                        connection.Open();
                        //     for (int t = 0; t < row.ItemArray.Count()-2; t++)

                        for (int t = mone; t < (mone+3); t++)
                        {
                            //  SET the values
                            command.Parameters["@ReqNo"].Value = int.Parse((dt.Rows[t][0]).ToString());
                            command.Parameters["@LineId"].Value = int.Parse((dt.Rows[t][1]).ToString());
                            command.Parameters["@ItemCode"].Value = (dt.Rows[t][2]).ToString();
                            command.Parameters["@Qntty"].Value = int.Parse((dt.Rows[t][3]).ToString()); ;
                            command.Parameters["@RequestStts"].Value = (dt.Rows[t][4]).ToString();
                            command.Parameters["@RejectRsn"].Value = (dt.Rows[t][5]).ToString();
                            command.Parameters["@BiilTo"].Value = int.Parse((dt.Rows[t][6]).ToString());
                           /* command.Parameters["@JCNum"].Value = int.Parse((dt.Rows[t][7]).ToString());
                            command.Parameters["@RjctMsg"].Value = (dt.Rows[t][8]).ToString();
                            command.Parameters["@StatusFlag"].Value = int.Parse((dt.Rows[t][9]).ToString());
                            command.Parameters["@Timestamp"].Value = DateTime.Parse(dt.Rows[t][10].ToString());*/
                            command.Parameters["@Docentry"].Value = int.Parse((dt.Rows[t][7]).ToString());
                            command.Parameters["@SBOLineId"].Value = int.Parse((dt.Rows[t][8]).ToString());
                            command.ExecuteNonQuery();
                        }
                        connection.Close();
                    }
                    mone = mone + 3;
                }
            if (count > 0)
                //יש פחות שורות מ3 ולכן ישלחו אחת אחרי השניה
                AddIntoPsRequestLineDetails(dt,count);
        }
        public static void CA_LogPs(DataTable dt,int NumOfRow)
        {  
            int count = dt.Rows.Count,i=NumOfRow;
            DataRow row = dt.Rows[i];
            if (count > 0)
            {
                string connectionString = m_ConnectionString;
               // var insertQuery = "INSERT into CA_Log_temp(ReqNo,LineId,ItemCode,Qntty,RequestStts,RejectRsn,BiilTo,JCNum,RjctMsg,StatusFlag,Timestamp) VALUES(@ReqNo,@LineId,@ItemCode,@Qntty,@RequestStts,@RejectRsn,@BiilTo,@JCNum,@RjctMsg,@StatusFlag,@Timestamp)";
               // var insertQuery = "INSERT into CA_Log_temp(ReqNo,LineId,ItemCode,Qntty,RequestStts,RejectRsn,BiilTo) VALUES(@ReqNo,@LineId,@ItemCode,@Qntty,@RequestStts,@RejectRsn,@BiilTo)";
              //https://stackoverflow.com/questions/9648934/insert-into-if-not-exists-sql-server
                var insertQuery = " IF NOT EXISTS (select * from CA_Log_temp where ReqNo = @ReqNo) \n\r" +
               " BEGIN \n\r" +
               "     INSERT into CA_Log_temp(ReqNo,LineId,ItemCode,Qntty,RequestStts,RejectRsn,BiilTo,Docentry,SBOLineId) VALUES(@ReqNo,@LineId,@ItemCode,@Qntty,@RequestStts,@RejectRsn,@BiilTo,@Docentry,@SBOLineId) \n\r" +
               " END \n\r " +
               " ELSE SELECT 0";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    // define your parameters ONCE outside the loop, and use EXPLICIT typing
                    command.Parameters.Add("@ReqNo", SqlDbType.Int);
                    command.Parameters.Add("@LineId", SqlDbType.Int);
                    command.Parameters.Add("@ItemCode", SqlDbType.NVarChar);
                    command.Parameters.Add("@Qntty", SqlDbType.Char);
                    command.Parameters.Add("@RequestStts", SqlDbType.NVarChar);
                    command.Parameters.Add("@RejectRsn", SqlDbType.NVarChar);
                    command.Parameters.Add("@BiilTo", SqlDbType.Int);
                 /*   command.Parameters.Add("@JCNum", SqlDbType.Int);
                    command.Parameters.Add("@RjctMsg", SqlDbType.NVarChar);
                    command.Parameters.Add("@StatusFlag", SqlDbType.Int);
                    command.Parameters.Add("@Timestamp", SqlDbType.DateTime);*/
                    command.Parameters.Add("@Docentry", SqlDbType.Int);
                    command.Parameters.Add("@SBOLineId", SqlDbType.Int);
                    connection.Open();

                    for (int t = i; t < (i+3); t++)
                    {
                        //  SET the values
                        command.Parameters["@ReqNo"].Value = int.Parse((dt.Rows[t][0]).ToString());
                        command.Parameters["@LineId"].Value = int.Parse((dt.Rows[t][1]).ToString());
                        command.Parameters["@ItemCode"].Value = (dt.Rows[t][2]).ToString();
                        command.Parameters["@Qntty"].Value = int.Parse((dt.Rows[t][3]).ToString()); ;
                        command.Parameters["@RequestStts"].Value = (dt.Rows[t][4]).ToString();
                        command.Parameters["@RejectRsn"].Value = (dt.Rows[t][5]).ToString();
                        command.Parameters["@BiilTo"].Value = int.Parse((dt.Rows[t][6]).ToString());
                    /*    command.Parameters["@JCNum"].Value = int.Parse((dt.Rows[t][7]).ToString());
                        command.Parameters["@RjctMsg"].Value = (dt.Rows[t][8]).ToString();
                        command.Parameters["@StatusFlag"].Value = int.Parse((dt.Rows[t][9]).ToString());
                        command.Parameters["@Timestamp"].Value = DateTime.Parse(dt.Rows[t][10].ToString());*/
                        command.Parameters["@Docentry"].Value = int.Parse((dt.Rows[t][7]).ToString());
                        command.Parameters["@SBOLineId"].Value = int.Parse((dt.Rows[t][8]).ToString());
                        command.ExecuteNonQuery();
                    }
                    connection.Close();
                }
            }
        }
        public void AddIntoPsFiles(DataTable dt)
        {
            int i = 0, count = dt.Rows.Count;
            //פרמטרים של טבלת CA_Files
            int ReqNo, LineId;
            string Descrptn, FileLink, FileName, AddTime;
            DateTime AddDate;
            //  DateTime AddDate, AddTime;
            while (dt.Rows.Count > 0 && count > 0)
            {
               
                    count--;
                    DataRow row = dt.Rows[i++];
                    if (row[6].ToString() != "")
                    {
                    ReqNo = int.Parse(row[0].ToString());
                    LineId = int.Parse(row[1].ToString());
                    Descrptn = row[2].ToString();
                    FileLink = row[3].ToString();
                    FileName = row[4].ToString();
                    AddDate = DateTime.Parse(row[5].ToString());
                    AddTime = row[6].ToString();

                    using (SqlConnection con = new SqlConnection(m_ConnectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand("Files_temp", con))
                        {
                            try
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add("@ReqNo", SqlDbType.Int).Value = ReqNo;
                                cmd.Parameters.Add("@LineId", SqlDbType.Int).Value = LineId;
                                cmd.Parameters.Add("@Descrptn", SqlDbType.NVarChar).Value = Descrptn;
                                cmd.Parameters.Add("@FileLink", SqlDbType.NVarChar).Value = FileLink;
                                cmd.Parameters.Add("@FileName", SqlDbType.NVarChar).Value = FileName;
                                cmd.Parameters.Add("@AddDate", SqlDbType.DateTime).Value = AddDate;
                                cmd.Parameters.Add("@AddTime", SqlDbType.NVarChar).Value = AddTime;
                            }
                            catch (Exception e)
                            {
                                EventManager.WriteEventErrorMessage("failed to put values for CA_Files table", e);
                            }
                            try
                            {
                                con.Open();
                                cmd.ExecuteNonQuery();
                            }
                            catch (Exception e)
                            {
                                EventManager.WriteEventErrorMessage("failed to open ConnectionString for CA_Files table", e);
                            }
                            try
                            {
                                con.Close();
                            }
                            catch (Exception e)
                            {
                                EventManager.WriteEventErrorMessage("failed to close ConnectionString for CA_Files table", e);
                            }
                        }
                    }
                }
            }
        }

         public void AddIntoPsFiles2(DataTable dt)
         {
            int i = 0, count = dt.Rows.Count;
            //פרמטרים של טבלת CA_Files
            int ReqNo, LineId;
            string Descrptn, FileLink, FileName;
      
          //  DateTime AddDate, AddTime;
           while (dt.Rows.Count > 0 && count > 0)
            {
                count--;
                DataRow row = dt.Rows[i++];
                if (row[6].ToString() == "")
                 {
                ReqNo = int.Parse(row[0].ToString());
                LineId = int.Parse(row[1].ToString());
                Descrptn = row[2].ToString();
                FileLink = row[3].ToString();
                FileName =row[4].ToString();

                using (SqlConnection con = new SqlConnection(m_ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Files_temp2", con))
                    {
                        try
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@ReqNo", SqlDbType.Int).Value = ReqNo;
                            cmd.Parameters.Add("@LineId", SqlDbType.Int).Value = LineId;
                            cmd.Parameters.Add("@Descrptn", SqlDbType.NVarChar).Value = Descrptn;
                            cmd.Parameters.Add("@FileLink", SqlDbType.NVarChar).Value = FileLink;
                            cmd.Parameters.Add("@FileName", SqlDbType.NVarChar).Value = FileName;
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to put values for CA_Files table", e);
                        }
                        try
                        {
                            con.Open();
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to open ConnectionString for CA_Files table", e);
                        }
                        try
                        {
                            con.Close();
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to close ConnectionString for CA_Files table", e);
                        }
                    }
                }
                }

            }
        }
    }
}

