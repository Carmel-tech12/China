﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.Net;
using System.Xml;
using System.Diagnostics;
using System.Configuration;

using System.Text.RegularExpressions;
using Microsoft.VisualBasic.FileIO;
using System.Data.SqlClient;

namespace DownLoadUpLoadDataService
{
    class Engine
    {
       
        private HttpWebRequest request;
        private CookieContainer cookieContainer = new CookieContainer();
        private static string m_ConnectionString = string.Empty;
        public static string m_folderpath = string.Empty;        
        public static string m_user = string.Empty;
        public static string m_pass = string.Empty;
        public static string m_url = string.Empty;
        public static string csv_file_path = string.Empty;
        public static string m_folderpathforzip = string.Empty;
        public static string m_userforzip = string.Empty;
        public static string m_passforzip = string.Empty;
        public static string m_urlxml = string.Empty;
        XmlDocument doc = new XmlDocument();
      
        public Engine()
        {
            LoadGlobalParameters();
        }

        private void LoadGlobalParameters()
        {
            try
            {
               // doc.Load("Config.xml");
               // doc.Load(@"C:\Program Files\UpLoadDataService\UpLoadDataService\bin\Debug\Config.xml");
                
                doc.Load(@""+ConfigurationManager.AppSettings["pathXml"]);
            }
            catch (Exception ex)
            {
               EventManager.WriteEventErrorMessage("can not load the doc", ex);
            }
            
            m_ConnectionString = doc.SelectSingleNode(@"Parameters/ConenctionString").InnerText+"&quot;";
            m_user = doc.SelectSingleNode(@"Parameters/Name").InnerText;
            m_pass = doc.SelectSingleNode(@"Parameters/Pass").InnerText;
            m_url = doc.SelectSingleNode(@"Parameters/Url").InnerText;
            m_userforzip = doc.SelectSingleNode(@"Parameters/Nameforzip").InnerText;
            m_passforzip = doc.SelectSingleNode(@"Parameters/Passforzip").InnerText;
            m_urlxml = doc.SelectSingleNode(@"Parameters/UrlXml").InnerText;
            m_folderpath = doc.SelectSingleNode(@"Parameters/folderpath").InnerText;
            m_folderpathforzip = doc.SelectSingleNode(@"Parameters/folderpathforzip").InnerText;
            ConnectionManager.ConnectionString = m_ConnectionString;
            ConnectionManager.Provider = doc.SelectSingleNode(@"Parameters/Provider").InnerText;
            csv_file_path = ConfigurationManager.AppSettings["pathofcsvfile"].ToString();
        }
        public static bool degel = true;
        public void InsertIntoSp()
        {
               EventManager.WriteEventInfoMessage("start ReadXml");
               // DataTable tblML = ConvertToDataTableML(csv_file_path, 25);
                DataTable tblML = ReadXmlForCA_RequestDetails();
               // EventManager.WriteEventInfoMessage("finish ConvertToDataTable ML from TxtFile");
               
                EventManager.WriteEventInfoMessage("start insert the data to PsRequestDetails from xml");
                AddIntoPsRequestDetails(tblML);
                EventManager.WriteEventInfoMessage("finish insert the data to PsRequestDetails from xml");

            //  EventManager.WriteEventInfoMessage("start ConvertToDataTable CL from TxtFile");
            //DataTable tblCL = ConvertToDataTableCL(csv_file_path, 11);
            //  EventManager.WriteEventInfoMessage("finish ConvertToDataTable CL from TxtFile");

            //EventManager.WriteEventInfoMessage("start AddIntoPsRequestDetails CL from TxtFile");
            //   CA_RequestLineDetailsPs(tblCL);
            //   EventManager.WriteEventInfoMessage("finish AddIntoPsRequestDetails CL from TxtFile");
               
                //EventManager.WriteEventInfoMessage("start InsertToFiles from TxtFile");
                //DataTable tfiles = InsertToFiles(tblCL);
                //EventManager.WriteEventInfoMessage("finish InsertToFiles from TxtFile");
        }
        public static DataTable ReadXmlForCA_RequestDetails()
        {
           // string url = @"https://chaina-motorsltd.dira2.co.il/chainamotors/systems/integrationFile.xml";
            //  string get = p1.getData(m_userforzip, m_passforzip, url);
            Engine e = new Engine();
            EventManager.WriteEventInfoMessage("try to do login");
            string get = e.getData(m_userforzip,m_passforzip,m_urlxml);
            EventManager.WriteEventInfoMessage("finish to do login");
            
            EventManager.WriteEventInfoMessage("start to loadxml");
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(get);
            EventManager.WriteEventInfoMessage("finish to loadxml");
            XmlNodeList nodeList = xmlDoc.GetElementsByTagName("datum");
         //   string id = "", idezer = "", car_mile_rage = "", failure_request_type = "", failure_request_rsn = "", failure_request_desc = "", description = "", time_car_entered = "";
            string ReqNo = "", RequestStts = "", ApproverName = "", LicNum = "", KM = "", RequestDt = "", RequestTypeCd = "", RequestTypeNm = "", RequestRsnCd = "", RequestRsnNm = "", RequestCd = "", RequestDesc = "", Notes = "", InternalNotes = "", CampaignCd = "", CampaignNm = "", OpenDt = "", FirstRspnsDt = "", EntryDt = "", EntryHr = "", ExitDt = "", ExitHr = "", Garage = "", EstCost = "";


             DataTable dt = new DataTable();
             for (int col = 0; col < 24; col++)
                 dt.Columns.Add(new DataColumn("Column" + (col + 1).ToString()));

        //     DataTable dt = ConvertToDataTableML(csv_file_path, 6);
             DataRow dr,  drLine;
             //מתבצעת ריצה על סוג בקשה בקריאה
             DataTable dtLine = new DataTable();
             for (int col = 0; col < 8; col++)
                 dtLine.Columns.Add(new DataColumn("Column" + (col + 1).ToString()));

            foreach (XmlNode node in nodeList)
            {
                dr = dt.NewRow();
                ReqNo = node.SelectSingleNode("ReqNo").InnerText;
                //מתבצעת ריצה על סוג בקשה בקריאה
               // XmlNodeList nodeListline = xmlDoc.GetElementsByTagName("orderline");
              
                XmlNodeList nodeListline = node.SelectNodes("orderlines"); //  can also use XPath here
                
                foreach (XmlNode nodeline in nodeListline)
                {
                    XmlNodeList nodeListline2 = nodeline.SelectNodes("orderline");
                    foreach (XmlNode nodeli in nodeListline2)
                    {

                       // string idreq = "", product_id = "", quantity = "", prodname = "", issue_type = "", status = "", item_key = "";
                        string LineId = "", ItemCode = "", Qntty = "", RequestSttsline = "", RejectRsn = "", BiilTo = "", InternalNotesline="";
                        LineId = nodeli.SelectSingleNode("LineId").InnerText;
                        ItemCode = nodeli.SelectSingleNode("ItemCode").InnerText;
                        Qntty = nodeli.SelectSingleNode("Qntty").InnerText;
                        RequestSttsline = nodeli.SelectSingleNode("RequestSttsline").InnerText;
                        RejectRsn = nodeli.SelectSingleNode("RejectRsn").InnerText;
                        BiilTo = nodeli.SelectSingleNode("BiilTo").InnerText;
                        InternalNotesline = nodeli.SelectSingleNode("InternalNotesline").InnerText;
                      
                        drLine = dtLine.NewRow();
                        //הכנסת נתונים לטבלה
                        drLine[0] = ReqNo;
                        drLine[1] = LineId;
                        drLine[2] = ItemCode;
                        drLine[3] = Qntty;
                        drLine[4] = RequestSttsline;
                        drLine[5] = RejectRsn;
                        drLine[6] = BiilTo;
                        drLine[7] = InternalNotesline;
                        dtLine.Rows.Add(drLine);
                    }
                }
                RequestStts = node.SelectSingleNode("RequestStts").InnerText;
                ApproverName = node.SelectSingleNode("ApproverName").InnerText;
                LicNum = node.SelectSingleNode("LicNum").InnerText;
                KM = node.SelectSingleNode("KM").InnerText;
                RequestDt = node.SelectSingleNode("RequestDt").InnerText;
                RequestTypeCd = node.SelectSingleNode("RequestTypeCd").InnerText;
                RequestTypeNm = node.SelectSingleNode("RequestTypeNm").InnerText;
                RequestRsnCd = node.SelectSingleNode("RequestRsnCd").InnerText;
                RequestRsnNm = node.SelectSingleNode("RequestRsnNm").InnerText;
                RequestCd = node.SelectSingleNode("RequestCd").InnerText;
                RequestDesc = node.SelectSingleNode("RequestDesc").InnerText;
                Notes = node.SelectSingleNode("Notes").InnerText;
                InternalNotes = node.SelectSingleNode("InternalNotes").InnerText;
                CampaignCd = node.SelectSingleNode("CampaignCd").InnerText;
                CampaignNm = node.SelectSingleNode("CampaignNm").InnerText;
                OpenDt = node.SelectSingleNode("OpenDt").InnerText;
                FirstRspnsDt = node.SelectSingleNode("FirstRspnsDt").InnerText;
                EntryDt = node.SelectSingleNode("EntryDt").InnerText;
                EntryHr = node.SelectSingleNode("EntryHr").InnerText;
                ExitDt = node.SelectSingleNode("ExitDt").InnerText;
                ExitHr = node.SelectSingleNode("ExitHr").InnerText;
                Garage = node.SelectSingleNode("Garage").InnerText;
                EstCost = node.SelectSingleNode("EstCost").InnerText;
                dr[0] = ReqNo;
                dr[1] = RequestStts;
                dr[2] = ApproverName;
                dr[3] = LicNum;
                dr[4] = KM;
                dr[5] = RequestDt;
                dr[6] = RequestTypeCd; 
                dr[7] = RequestTypeNm;
                dr[8] = RequestRsnCd;
                dr[9] = RequestRsnNm;
                dr[10] = RequestCd;
                dr[11] = RequestDesc;
                dr[12] = Notes;
                dr[13] = InternalNotes;
                dr[14] = CampaignCd;
                dr[15] = CampaignNm;
                dr[16] = OpenDt;
                dr[17] = FirstRspnsDt;
                dr[18] = EntryDt;
                dr[19] = EntryHr;
                dr[20] = ExitDt;
                dr[21] = ExitHr;
                dr[22] = Garage;
                dr[23] = EstCost;
                dt.Rows.Add(dr);  
            }
            CA_RequestLineDetailsPs(dtLine);
            InsertToFiles(dtLine);
            return dt;
        }
       public static DataTable InsertToFiles(DataTable tblCL)
        {
            DataTable tblFiles = new DataTable();
            for (int col = 0; col < 11; col++)
                tblFiles.Columns.Add(new DataColumn("Column" + (col + 1).ToString()));
            int ReqNo, LineId;
            string Descrptn="", FileLink, FileName="",AddTime="";
            DateTime AddDate=new DateTime(); 
           degel = true;
       foreach (DataRow dr in tblCL.Rows) 
       {
          
           ReqNo = int.Parse(dr[0].ToString());
           LineId = int.Parse(dr[1].ToString());
         //  Descrptn = (dr[10].ToString().Substring(dr[12].ToString().IndexOf(".")));
           FileLink = "";
           if (dr[9].ToString() != "" && dr[10].ToString() != "")
           {
               degel = true;
               Descrptn = (dr[9].ToString().Substring(dr[9].ToString().IndexOf(".") + 1));
               FileName = (dr[9].ToString().Substring(0, dr[9].ToString().IndexOf(".")));
               AddDate = DateTime.Parse(dr[10].ToString().Substring(0, 11));
               AddTime = dr[10].ToString().Substring(11);
           }
           else
               degel = false;
           DataRow workRow = tblFiles.NewRow();
           workRow[0] = ReqNo;
           workRow[1] = LineId;
           workRow[2] = Descrptn;
           workRow[3] = FileLink;
           if (dr[9].ToString() != "" && dr[10].ToString() != "")
           {
               degel = true;
               workRow[4] = FileName;
               workRow[5] = AddDate;
               workRow[6] = AddTime;
           }
           else
               degel = false;
           
           tblFiles.Rows.Add(workRow);
      
           if(degel)
              AddIntoPsFiles(tblFiles);
           else
               AddIntoPsFiles2(tblFiles);
       }
            return tblFiles;
        }

      //  https://stackoverflow.com/questions/20860101/how-to-read-text-file-to-datatable
     
     
         //  https://social.msdn.microsoft.com/Forums/vstudio/en-US/f14523f8-3a40-451b-983b-ae4f5fd12697/how-to-load-data-from-csv-file-in-temp-table-in-c?forum=csharpgeneral
            public void AddIntoPsRequestDetails(DataTable dt)
        {
       // https://stackoverflow.com/questions/29046715/extract-values-from-datatable-with-single-row

            int i = 0, count = dt.Rows.Count; 
            //פרמטרים של טבלת CA_RequestDetails
            string CampaignCd, EstCost;
            int ReqNo, KM, RequestTypeCd, JCNum, RequestChangeFlag, RequestRsnCd, RequestCd, StatusFlag;//EstCost
            string ApproverName, LicNum, RequestTypeNm, RequestDesc, CampaignNm, EntryHr, ExitHr, Garage, RequestStts, RequestRsnNm, Notes;
            DateTime RequestDt, EntryDt, ExitDt, TimeStamp, OpenDt, FirstRspnsDt;
             while (dt.Rows.Count > 0 && count > 0)
              {
                count--;
              DataRow row = dt.Rows[i++];
                //זימון פונקציה שתבדוק עבור סוג בקשה אם קיים אם כן תעדכן תאור אחרת תוסיף לטבלה
              ReqNo = int.Parse(row[0].ToString());
              RequestStts = row[1].ToString();
	          ApproverName = row[2].ToString(); 
	          LicNum = row[3].ToString(); 
	          KM = int.Parse(row[4].ToString()); 
              RequestDt = DateTime.Parse( row[5].ToString()); 
	          RequestTypeCd= int.Parse(row[6].ToString()); 
	          RequestTypeNm = row[7].ToString();
              RequestRsnCd = int.Parse(row[8].ToString());
              RequestRsnNm=row[9].ToString();
              RequestCd=int.Parse(row[10].ToString());
              RequestDesc = row[11].ToString(); 
              Notes=row[12].ToString();
              CampaignCd = row[13].ToString();
	          CampaignNm = row[14].ToString();
              OpenDt=DateTime.Parse(row[15].ToString());
              FirstRspnsDt = DateTime.Parse(row[16].ToString());
	          EntryDt = DateTime.Parse(row[17].ToString()); 
	          EntryHr = row[18].ToString(); 
	          ExitDt = DateTime.Parse(row[19].ToString()); 
	          ExitHr = row[20].ToString(); 
	          Garage = row[21].ToString(); 
              EstCost = row[22].ToString();
	         // JCNum = int.Parse(row[16].ToString());
	         // RequestChangeFlag = int.Parse(row[17].ToString()); 
	        // TimeStamp = DateTime.Parse(row[18].ToString());
              StatusFlag = int.Parse(row[23].ToString()); 
               TimeStamp = DateTime.Parse(row[24].ToString());
              EventManager.WriteEventInfoMessage("start ConnectionString to db for CA_RequestDetails table");
            using (SqlConnection con = new SqlConnection(m_ConnectionString)) {
                using (SqlCommand cmd = new SqlCommand("RequestDetails_temp", con))
                {
                    try
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add("@ReqNo", SqlDbType.Int).Value = ReqNo;
                        cmd.Parameters.Add("@RequestStts", SqlDbType.NVarChar).Value = RequestStts;
                        cmd.Parameters.Add("@ApproverName", SqlDbType.NVarChar).Value = ApproverName;
                        cmd.Parameters.Add("@LicNum", SqlDbType.NVarChar).Value = LicNum;
                        cmd.Parameters.Add("@KM", SqlDbType.Int).Value = KM;
                        cmd.Parameters.Add("@RequestDt", SqlDbType.DateTime).Value = RequestDt;
                        cmd.Parameters.Add("@RequestTypeCd", SqlDbType.Int).Value = RequestTypeCd;
                        cmd.Parameters.Add("@RequestTypeNm", SqlDbType.NVarChar).Value = RequestTypeNm;
                        cmd.Parameters.Add("@RequestRsnCd", SqlDbType.Int).Value = RequestRsnCd;
                        cmd.Parameters.Add("@RequestRsnNm", SqlDbType.NVarChar).Value = RequestRsnNm;
                        cmd.Parameters.Add("@RequestCd", SqlDbType.Int).Value = RequestCd;
                        cmd.Parameters.Add("@RequestDesc", SqlDbType.NVarChar).Value = RequestDesc;
                        cmd.Parameters.Add("@Notes", SqlDbType.NVarChar).Value = Notes;
                        cmd.Parameters.Add("@CampaignCd", SqlDbType.NVarChar).Value = CampaignCd;
                        cmd.Parameters.Add("@CampaignNm", SqlDbType.NVarChar).Value = CampaignNm;
                        cmd.Parameters.Add("@OpenDt", SqlDbType.DateTime).Value = OpenDt;
                        cmd.Parameters.Add("@FirstRspnsDt", SqlDbType.DateTime).Value = FirstRspnsDt;
                        cmd.Parameters.Add("@EntryDt", SqlDbType.DateTime).Value = EntryDt;
                        cmd.Parameters.Add("@EntryHr", SqlDbType.NVarChar).Value = EntryHr;
                        cmd.Parameters.Add("@ExitDt", SqlDbType.DateTime).Value = ExitDt;
                        cmd.Parameters.Add("@ExitHr", SqlDbType.NVarChar).Value = ExitHr;
                        cmd.Parameters.Add("@Garage", SqlDbType.NVarChar).Value = Garage;
                        cmd.Parameters.Add("@EstCost", SqlDbType.NVarChar).Value = EstCost;
                        //cmd.Parameters.Add("@JCNum", SqlDbType.Int).Value = JCNum;
                        //cmd.Parameters.Add("@RequestChangeFlag", SqlDbType.Int).Value = RequestChangeFlag;
                    //    cmd.Parameters.Add("@StatusFlag", SqlDbType.Int).Value = RequestChangeFlag;
                       // '@StatusFlag'
                      //  cmd.Parameters.Add("@TimeStamp", SqlDbType.DateTime).Value = TimeStamp;
                        cmd.Parameters.Add("@StatusFlag", SqlDbType.Int).Value = StatusFlag;
                        cmd.Parameters.Add("@TimeStamp", SqlDbType.DateTime).Value = TimeStamp;
                    }
                    catch (Exception e)
                    {
                        EventManager.WriteEventErrorMessage("failed to put values for CA_RequestDetails table",e);
                    }
                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception e)
                    {
                        EventManager.WriteEventErrorMessage("failed to open ConnectionString for CA_RequestDetails table", e);
                    }
                    try
                    {
                        con.Close();
                    }
                    catch (Exception e)
                    {
                        EventManager.WriteEventErrorMessage("failed to close ConnectionString for CA_RequestDetails table", e);
                    }
                } 
             }  
             
   
        }
      }
            public static void AddIntoPsRequestLineDetails(DataTable dt,int NumOfRow)
        {
            int i , count = dt.Rows.Count;
            //פרמטרים של טבלת CA_RequestLineDetails
            char Qntty;
            int ReqNo, LineId,BiilTo,JCNum,StatusFlag,Docentry,SBOLineId;
            string ItemCode,RequestStts,RejectRsn,RjctMsg,FileName;
            DateTime Timestamp,AddTime;
            i = count - NumOfRow;
            count = NumOfRow;
            while (dt.Rows.Count > 0 && count > 0)
            {
                count--;
                DataRow row = dt.Rows[i++];
                ReqNo = int.Parse(row[0].ToString());
                LineId = int.Parse(row[1].ToString());
                ItemCode = row[2].ToString();
                Qntty = Char.Parse(row[3].ToString());
                RequestStts = row[4].ToString();
                RejectRsn = row[5].ToString();
                BiilTo = int.Parse(row[6].ToString());
              /*  JCNum = int.Parse(row[7].ToString());
                RjctMsg = row[8].ToString();
                StatusFlag = int.Parse(row[9].ToString());
                Timestamp = DateTime.Parse(row[10].ToString());*/
                    Docentry=int.Parse(row[7].ToString());
                    SBOLineId=int.Parse(row[8].ToString());
                using (SqlConnection con = new SqlConnection(m_ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("RequestLineDetails_temp", con))
                    {
                        try
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@ReqNo", SqlDbType.Int).Value = ReqNo;
                            cmd.Parameters.Add("@LineId", SqlDbType.Int).Value = LineId;
                            cmd.Parameters.Add("@ItemCode", SqlDbType.NVarChar).Value = ItemCode;
                            cmd.Parameters.Add("@Qntty", SqlDbType.Char).Value = Qntty;
                            cmd.Parameters.Add("@RequestStts", SqlDbType.NVarChar).Value = RequestStts;
                            cmd.Parameters.Add("@RejectRsn", SqlDbType.NVarChar).Value = RejectRsn;
                            cmd.Parameters.Add("@BiilTo", SqlDbType.Int).Value = BiilTo;
                         /* cmd.Parameters.Add("@JCNum", SqlDbType.Int).Value = JCNum;
                            cmd.Parameters.Add("@RjctMsg", SqlDbType.NVarChar).Value = RjctMsg;
                            cmd.Parameters.Add("@StatusFlag", SqlDbType.Int).Value = StatusFlag;
                            cmd.Parameters.Add("@Timestamp", SqlDbType.DateTime).Value = Timestamp;*/
                            cmd.Parameters.Add("@Docentry", SqlDbType.Int).Value = Docentry;
                            cmd.Parameters.Add("@SBOLineId", SqlDbType.Int).Value = SBOLineId;
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to put values for CA_RequestLineDetails table", e);
                        }
                        try
                        {
                            con.Open();
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to open ConnectionString for CA_RequestLineDetails table", e);
                        }
                        try
                        {
                            con.Close();
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to close ConnectionString for CA_RequestLineDetails table", e);
                        }
                    }
                }


            }
        }
            public static void CA_RequestLineDetailsPs(DataTable dt)
        {
            int count = dt.Rows.Count,mone = 0; 
            string connectionString = m_ConnectionString;
       // https://stackoverflow.com/questions/9648934/insert-into-if-not-exists-sql-server
           /* string insertQuery = " IF NOT EXISTS (select * from CA_RequestLineDetails_temp where ReqNo = @ReqNo) \n\r" +
               " BEGIN \n\r" +
               "     INSERT into CA_RequestLineDetails_temp(ReqNo,LineId,ItemCode,Qntty,RequestStts,RejectRsn,BiilTo) VALUES(@ReqNo,@LineId,@ItemCode,@Qntty,@RequestStts,@RejectRsn,@BiilTo) \n\r" +
               " END \n\r " +
               " ELSE SELECT 0";*/
            string insertQuery = " IF NOT EXISTS (select * from CA_RequestLineDetails_temp where ReqNo = @ReqNo) \n\r" +
              " BEGIN \n\r" +
              "     INSERT into CA_RequestLineDetails_temp(ReqNo,LineId,ItemCode,Qntty,RequestStts,RejectRsn,BiilTo,Docentry,SBOLineId) VALUES(@ReqNo,@LineId,@ItemCode,@Qntty,@RequestStts,@RejectRsn,@BiilTo,@Docentry,@SBOLineId) \n\r" +
              " END \n\r " +
              " ELSE SELECT 0";
            using (SqlConnection connection = new SqlConnection(connectionString))
                while (count > 0 && count > 3)
                {
                    DataRow row = dt.Rows[mone];
                    CA_LogPs(dt, mone);
                   
                    count = count - 3;
                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        // define your parameters ONCE outside the loop, and use EXPLICIT typing
                        command.Parameters.Add("@ReqNo", SqlDbType.Int);
                        command.Parameters.Add("@LineId", SqlDbType.Int);
                        command.Parameters.Add("@ItemCode", SqlDbType.NVarChar);
                        command.Parameters.Add("@Qntty", SqlDbType.Char);
                        command.Parameters.Add("@RequestStts", SqlDbType.NVarChar);
                        command.Parameters.Add("@RejectRsn", SqlDbType.NVarChar);
                        command.Parameters.Add("@BiilTo", SqlDbType.Int);
                       /* command.Parameters.Add("@JCNum", SqlDbType.Int);
                        command.Parameters.Add("@RjctMsg", SqlDbType.NVarChar);
                        command.Parameters.Add("@StatusFlag", SqlDbType.Int);
                        command.Parameters.Add("@Timestamp", SqlDbType.DateTime);*/
                         command.Parameters.Add("@Docentry", SqlDbType.Int);
                         command.Parameters.Add("@SBOLineId", SqlDbType.Int);
                        connection.Open();
                        //     for (int t = 0; t < row.ItemArray.Count()-2; t++)

                        for (int t = mone; t < (mone+3); t++)
                        {
                            //  SET the values
                            command.Parameters["@ReqNo"].Value = int.Parse((dt.Rows[t][0]).ToString());
                            command.Parameters["@LineId"].Value = int.Parse((dt.Rows[t][1]).ToString());
                            command.Parameters["@ItemCode"].Value = (dt.Rows[t][2]).ToString();
                            command.Parameters["@Qntty"].Value = int.Parse((dt.Rows[t][3]).ToString()); ;
                            command.Parameters["@RequestStts"].Value = (dt.Rows[t][4]).ToString();
                            command.Parameters["@RejectRsn"].Value = (dt.Rows[t][5]).ToString();
                            command.Parameters["@BiilTo"].Value = int.Parse((dt.Rows[t][6]).ToString());
                           /* command.Parameters["@JCNum"].Value = int.Parse((dt.Rows[t][7]).ToString());
                            command.Parameters["@RjctMsg"].Value = (dt.Rows[t][8]).ToString();
                            command.Parameters["@StatusFlag"].Value = int.Parse((dt.Rows[t][9]).ToString());
                            command.Parameters["@Timestamp"].Value = DateTime.Parse(dt.Rows[t][10].ToString());*/
                            command.Parameters["@Docentry"].Value = int.Parse((dt.Rows[t][7]).ToString());
                            command.Parameters["@SBOLineId"].Value = int.Parse((dt.Rows[t][8]).ToString());
                            command.ExecuteNonQuery();
                        }
                        connection.Close();
                    }
                    mone = mone + 3;
                }
            if (count > 0)
                //יש פחות שורות מ3 ולכן ישלחו אחת אחרי השניה
                AddIntoPsRequestLineDetails(dt,count);
        }
            public static void CA_LogPs(DataTable dt,int NumOfRow)
        {  
            int count = dt.Rows.Count,i=NumOfRow;
            DataRow row = dt.Rows[i];
            if (count > 0)
            {
                string connectionString = m_ConnectionString;
               // var insertQuery = "INSERT into CA_Log_temp(ReqNo,LineId,ItemCode,Qntty,RequestStts,RejectRsn,BiilTo,JCNum,RjctMsg,StatusFlag,Timestamp) VALUES(@ReqNo,@LineId,@ItemCode,@Qntty,@RequestStts,@RejectRsn,@BiilTo,@JCNum,@RjctMsg,@StatusFlag,@Timestamp)";
               // var insertQuery = "INSERT into CA_Log_temp(ReqNo,LineId,ItemCode,Qntty,RequestStts,RejectRsn,BiilTo) VALUES(@ReqNo,@LineId,@ItemCode,@Qntty,@RequestStts,@RejectRsn,@BiilTo)";
              //https://stackoverflow.com/questions/9648934/insert-into-if-not-exists-sql-server
                var insertQuery = " IF NOT EXISTS (select * from CA_Log_temp where ReqNo = @ReqNo) \n\r" +
               " BEGIN \n\r" +
               "     INSERT into CA_Log_temp(ReqNo,LineId,ItemCode,Qntty,RequestStts,RejectRsn,BiilTo,Docentry,SBOLineId) VALUES(@ReqNo,@LineId,@ItemCode,@Qntty,@RequestStts,@RejectRsn,@BiilTo,@Docentry,@SBOLineId) \n\r" +
               " END \n\r " +
               " ELSE SELECT 0";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    // define your parameters ONCE outside the loop, and use EXPLICIT typing
                    command.Parameters.Add("@ReqNo", SqlDbType.Int);
                    command.Parameters.Add("@LineId", SqlDbType.Int);
                    command.Parameters.Add("@ItemCode", SqlDbType.NVarChar);
                    command.Parameters.Add("@Qntty", SqlDbType.Char);
                    command.Parameters.Add("@RequestStts", SqlDbType.NVarChar);
                    command.Parameters.Add("@RejectRsn", SqlDbType.NVarChar);
                    command.Parameters.Add("@BiilTo", SqlDbType.Int);
                 /*   command.Parameters.Add("@JCNum", SqlDbType.Int);
                    command.Parameters.Add("@RjctMsg", SqlDbType.NVarChar);
                    command.Parameters.Add("@StatusFlag", SqlDbType.Int);
                    command.Parameters.Add("@Timestamp", SqlDbType.DateTime);*/
                    command.Parameters.Add("@Docentry", SqlDbType.Int);
                    command.Parameters.Add("@SBOLineId", SqlDbType.Int);
                    connection.Open();

                    for (int t = i; t < (i+3); t++)
                    {
                        //  SET the values
                        command.Parameters["@ReqNo"].Value = int.Parse((dt.Rows[t][0]).ToString());
                        command.Parameters["@LineId"].Value = int.Parse((dt.Rows[t][1]).ToString());
                        command.Parameters["@ItemCode"].Value = (dt.Rows[t][2]).ToString();
                        command.Parameters["@Qntty"].Value = int.Parse((dt.Rows[t][3]).ToString()); ;
                        command.Parameters["@RequestStts"].Value = (dt.Rows[t][4]).ToString();
                        command.Parameters["@RejectRsn"].Value = (dt.Rows[t][5]).ToString();
                        command.Parameters["@BiilTo"].Value = int.Parse((dt.Rows[t][6]).ToString());
                    /*    command.Parameters["@JCNum"].Value = int.Parse((dt.Rows[t][7]).ToString());
                        command.Parameters["@RjctMsg"].Value = (dt.Rows[t][8]).ToString();
                        command.Parameters["@StatusFlag"].Value = int.Parse((dt.Rows[t][9]).ToString());
                        command.Parameters["@Timestamp"].Value = DateTime.Parse(dt.Rows[t][10].ToString());*/
                        command.Parameters["@Docentry"].Value = int.Parse((dt.Rows[t][7]).ToString());
                        command.Parameters["@SBOLineId"].Value = int.Parse((dt.Rows[t][8]).ToString());
                        command.ExecuteNonQuery();
                    }
                    connection.Close();
                }
            }
        }
            public static void AddIntoPsFiles(DataTable dt)
        {
            int i = 0, count = dt.Rows.Count;
            //פרמטרים של טבלת CA_Files
            int ReqNo, LineId;
            string Descrptn, FileLink, FileName, AddTime;
            DateTime AddDate;
            //  DateTime AddDate, AddTime;
            while (dt.Rows.Count > 0 && count > 0)
            {
               
                    count--;
                    DataRow row = dt.Rows[i++];
                    if (row[6].ToString() != "")
                    {
                    ReqNo = int.Parse(row[0].ToString());
                    LineId = int.Parse(row[1].ToString());
                    Descrptn = row[2].ToString();
                    FileLink = row[3].ToString();
                    FileName = row[4].ToString();
                    AddDate = DateTime.Parse(row[5].ToString());
                    AddTime = row[6].ToString();

                    using (SqlConnection con = new SqlConnection(m_ConnectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand("Files_temp", con))
                        {
                            try
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add("@ReqNo", SqlDbType.Int).Value = ReqNo;
                                cmd.Parameters.Add("@LineId", SqlDbType.Int).Value = LineId;
                                cmd.Parameters.Add("@Descrptn", SqlDbType.NVarChar).Value = Descrptn;
                                cmd.Parameters.Add("@FileLink", SqlDbType.NVarChar).Value = FileLink;
                                cmd.Parameters.Add("@FileName", SqlDbType.NVarChar).Value = FileName;
                                cmd.Parameters.Add("@AddDate", SqlDbType.DateTime).Value = AddDate;
                                cmd.Parameters.Add("@AddTime", SqlDbType.NVarChar).Value = AddTime;
                            }
                            catch (Exception e)
                            {
                                EventManager.WriteEventErrorMessage("failed to put values for CA_Files table", e);
                            }
                            try
                            {
                                con.Open();
                                cmd.ExecuteNonQuery();
                            }
                            catch (Exception e)
                            {
                                EventManager.WriteEventErrorMessage("failed to open ConnectionString for CA_Files table", e);
                            }
                            try
                            {
                                con.Close();
                            }
                            catch (Exception e)
                            {
                                EventManager.WriteEventErrorMessage("failed to close ConnectionString for CA_Files table", e);
                            }
                        }
                    }
                }
            }
        }
            public static void AddIntoPsFiles2(DataTable dt)
         {
            int i = 0, count = dt.Rows.Count;
            //פרמטרים של טבלת CA_Files
            int ReqNo, LineId;
            string Descrptn, FileLink, FileName;
      
          //  DateTime AddDate, AddTime;
           while (dt.Rows.Count > 0 && count > 0)
            {
                count--;
                DataRow row = dt.Rows[i++];
                if (row[6].ToString() == "")
                 {
                ReqNo = int.Parse(row[0].ToString());
                LineId = int.Parse(row[1].ToString());
                Descrptn = row[2].ToString();
                FileLink = row[3].ToString();
                FileName =row[4].ToString();

                using (SqlConnection con = new SqlConnection(m_ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Files_temp2", con))
                    {
                        try
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.Add("@ReqNo", SqlDbType.Int).Value = ReqNo;
                            cmd.Parameters.Add("@LineId", SqlDbType.Int).Value = LineId;
                            cmd.Parameters.Add("@Descrptn", SqlDbType.NVarChar).Value = Descrptn;
                            cmd.Parameters.Add("@FileLink", SqlDbType.NVarChar).Value = FileLink;
                            cmd.Parameters.Add("@FileName", SqlDbType.NVarChar).Value = FileName;
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to put values for CA_Files table", e);
                        }
                        try
                        {
                            con.Open();
                            cmd.ExecuteNonQuery();
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to open ConnectionString for CA_Files table", e);
                        }
                        try
                        {
                            con.Close();
                        }
                        catch (Exception e)
                        {
                            EventManager.WriteEventErrorMessage("failed to close ConnectionString for CA_Files table", e);
                        }
                    }
                }
              } 

            }
        }

            //פונקציה שמבצעת התחברות ל
            //URL
            // עם יוזר וסיסמא
            public String getData(string uid, string pwd, string url)
            {
                // Create a request using a URL that can receive a post. 
                request = (HttpWebRequest)HttpWebRequest.Create(url);
                request.CookieContainer = cookieContainer;
                //added by liat in case customer has proxy 25/04/2016  
                IWebProxy wp = WebRequest.DefaultWebProxy;
                wp.Credentials = CredentialCache.DefaultCredentials;
                request.Proxy = wp;
                //end Change
                // Set the Method property of the request to POST.
                request.Method = "POST";

                // Set the ContentType property of the WebRequest.
                request.ContentType = "application/x-www-form-urlencoded";

                // Create POST data and convert it to a byte array.
                string postData = "email=" + uid + "&password=" + pwd;
                byte[] byteArray = Encoding.UTF8.GetBytes(postData);

                // Set the ContentLength property of the WebRequest.
                request.ContentLength = byteArray.Length;
                request.KeepAlive = true;

                // Get the request stream.
                using (Stream dataStream = request.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);
                }
                try
                {
                    HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                    response.Cookies = request.CookieContainer.GetCookies(request.RequestUri);
                    String resptext = "";
                    using (Stream stream = response.GetResponseStream())
                    {
                        StreamReader reader = new StreamReader(stream, Encoding.UTF8);
                        resptext = reader.ReadToEnd();
                    }


                    response.Close();
                    return resptext;
                }
                catch (WebException we)
                {

                }
                catch (Exception we)
                {
                }
                //HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                //response.Cookies = request.CookieContainer.GetCookies(request.RequestUri);
                //response.Close();
                return "";

            } 

    }
}

